#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>

void pressAnyKeyToContinue()
{
    std::cout << std::endl;
    system("pause");
    system("cls");
    std::cout << "------------ Farm Management and Crop Life Cycle Tracker ------------" << std::endl
              << std::endl;
}

class UniqueIDGenerator
{
private:
    static int fieldIDCounter;
    static int cropIDCounter;

public:
    static int generateFieldID();
    static int generateCropID();
};

int UniqueIDGenerator::fieldIDCounter = 0;
int UniqueIDGenerator::cropIDCounter = 0;

class Crop;
class CropStage
{
    std::string name;
    std::string description;
    std::string startDate;
    std::string endDate;

    CropStage *next;
    CropStage *prev;

public:
    CropStage(const std::string &name, const std::string &description,
              const std::string &startDate, const std::string &endDate);
    friend class Crop;

    std::string getName() const;
    std::string getDescription() const;
    std::string getStartDate() const;
    std::string getEndDate() const;
    const CropStage *getNext() const;
    const CropStage *getPrev() const;

    void setName(const std::string &newName);
    void setDescription(const std::string &newDescription);
    void setStartDate(const std::string &newStartDate);
    void setEndDate(const std::string &newEndDate);
};

class Crop
{
    int id;
    int fieldId;
    std::string name;
    std::string type;
    std::string supplier;
    std::string nutritionalInformation;
    int inventory;
    double costPerUnit;

    CropStage *stages; // first stage

public:
    Crop(const std::string &name, const std::string &type, const std::string &supplier,
         const std::string &nutritionalInformation, int inventory, double costPerUnit);

    int getId() const;
    int getFieldId() const;
    std::string getName() const;
    std::string getType() const;
    std::string getSupplier() const;
    std::string getNutritionalInformation() const;
    int getInventory() const;
    double getCostPerUnit() const;
    const CropStage *getStages() const;

    void setFieldId(int newFieldId);
    void setName(const std::string &newName);
    void setType(const std::string &newType);
    void setSupplier(const std::string &newSupplier);
    void setNutritionalInformation(const std::string &newNutritionalInformation);
    void setInventory(int newInventory);
    void setCostPerUnit(double newCostPerUnit);
    void addStage(const std::string &stageName, const std::string &description,
                  const std::string &startDate, const std::string &endDate);
};

class Field
{
    int id;
    std::string name;
    int area;
    std::vector<int> cropIds;

public:
    Field(const std::string &fieldName, int fieldArea);

    int getId() const;
    std::string getName() const;
    int getArea() const;
    const std::vector<int> getCropIds() const;

    void setName(const std::string &newName);
    void setArea(int newArea);
    void addCropId(int cropId);
    void removeCropId(int cropId);
};

class Menu
{
    static char getUserChoice();

public:
    static char mainMenu();
    static char fieldsMenu();
    static char fieldOptionsMenu();
    static char changeFieldInformationMenu();
    static char cropsMenu();
    static char cropOptionsMenu();
    static char changeCropInformationMenu();
};

class FarmManager
{
private:
    std::vector<Field> fields;
    std::vector<Crop> crops;

public:
    FarmManager();

    void changeFieldName(Field *field);
    void changeFieldArea(Field *field);
    void addCropInField(Field *field);
    void removeCropFromField(Field *field);
    void viewCropsInField(Field *field);
    void searchField();
    void addField();
    void deleteField();
    int binarySearchCrop(const std::vector<Crop> &crops, int targetId);
    void viewAllFields();
    void changeCropName(Crop *crop);
    void changeCropType(Crop *crop);
    void changeCropSupplier(Crop *crop);
    void changeCropNutritionalInformation(Crop *crop);
    void changeCropInventory(Crop *crop);
    void changeCropCostPerUnit(Crop *crop);
    void addCropStage(Crop *crop);
    void searchCrop();
    void addCrop();
    void deleteCrop();
    void viewAllCrops();
    int partitionCrops(std::vector<Crop> &quickCrops, int low, int high);
    void quickSortCrops(std::vector<Crop> &quickCrops, int low, int high);
    int partitionFields(std::vector<Field> &quickFields, int low, int high);
    void quickSortFields(std::vector<Field> &quickFields, int low, int high);
    void generateReport();
};

int main()
{
    FarmManager farm;

    while (true)
    {
        system("cls");
        std::cout << "------------ Farm Management and Crop Life Cycle Tracker ------------" << std::endl
                  << std::endl;

        char mainChoice = Menu::mainMenu();

        switch (mainChoice)
        {
        case '1':
        {
            char fieldsChoice;
            do
            {
                fieldsChoice = Menu::fieldsMenu();

                switch (fieldsChoice)
                {
                case '1':
                    farm.searchField();
                    break;
                case '2':
                    farm.addField();
                    pressAnyKeyToContinue();
                    break;
                case '3':
                    farm.deleteField();
                    pressAnyKeyToContinue();
                    break;
                case '4':
                    farm.viewAllFields();
                    pressAnyKeyToContinue();
                    break;
                case '5':
                    break;
                default:
                    std::cout << "Invalid choice. Please try again." << std::endl;
                    pressAnyKeyToContinue();
                    break;
                }
            } while (fieldsChoice != '5');
            break;
        }
        case '2':
        {
            char cropsChoice;
            do
            {
                cropsChoice = Menu::cropsMenu();

                switch (cropsChoice)
                {
                case '1':
                    farm.searchCrop();
                    break;
                case '2':
                    farm.addCrop();
                    pressAnyKeyToContinue();
                    break;
                case '3':
                    farm.deleteCrop();
                    pressAnyKeyToContinue();
                    break;
                case '4':
                    farm.viewAllCrops();
                    pressAnyKeyToContinue();
                    break;
                case '5':
                    break;

                default:
                    std::cout << "Invalid choice. Please try again." << std::endl;
                    pressAnyKeyToContinue();
                    break;
                }
            } while (cropsChoice != '5');
            break;
        }
        case '3':
            farm.generateReport();
            pressAnyKeyToContinue();
            break;
        case '4':
            std::cout << "Exiting the program." << std::endl;
            return 0;
        default:
            std::cout << "Invalid choice. Please try again." << std::endl;
        }
    }

    return 0;
}

// Unique ID Generator

int UniqueIDGenerator::generateFieldID()
{
    return ++fieldIDCounter;
}

int UniqueIDGenerator::generateCropID()
{
    return ++cropIDCounter;
}

// Crop Stage Class

CropStage::CropStage(const std::string &name, const std::string &description,
                     const std::string &startDate, const std::string &endDate)
    : name(name), description(description), startDate(startDate),
      endDate(endDate), next(nullptr), prev(nullptr) {}

std::string CropStage::getName() const
{
    return this->name;
};
std::string CropStage::getDescription() const
{
    return this->description;
};
std::string CropStage::getStartDate() const
{
    return this->startDate;
};
std::string CropStage::getEndDate() const
{
    return this->endDate;
};
const CropStage *CropStage::getNext() const
{
    return this->next;
};
const CropStage *CropStage::getPrev() const
{
    return this->prev;
};

void CropStage::setName(const std::string &newName)
{
    this->name = newName;
};
void CropStage::setDescription(const std::string &newDescription)
{
    this->description = newDescription;
};
void CropStage::setStartDate(const std::string &newStartDate)
{
    this->startDate = newStartDate;
};
void CropStage::setEndDate(const std::string &newEndDate)
{
    this->endDate = newEndDate;
};

// Crop Class

Crop::Crop(const std::string &name, const std::string &type, const std::string &supplier,
           const std::string &nutritionalInformation, int inventory, double costPerUnit)
    : fieldId(-1), name(name), type(type), supplier(supplier), nutritionalInformation(nutritionalInformation),
      inventory(inventory), costPerUnit(costPerUnit), stages(nullptr)
{
    this->id = UniqueIDGenerator::generateCropID();
}

int Crop::getId() const
{
    return this->id;
}
int Crop::getFieldId() const
{
    return this->fieldId;
};
std::string Crop::getName() const
{
    return this->name;
};
std::string Crop::getType() const
{
    return this->type;
};
std::string Crop::getSupplier() const
{
    return this->supplier;
};
std::string Crop::getNutritionalInformation() const
{
    return this->nutritionalInformation;
};
int Crop::getInventory() const
{
    return this->inventory;
};
double Crop::getCostPerUnit() const
{
    return this->costPerUnit;
};
const CropStage *Crop::getStages() const
{
    return this->stages;
};

void Crop::setFieldId(int newFieldId)
{
    this->fieldId = newFieldId;
}
void Crop::setName(const std::string &newName)
{
    this->name = newName;
};
void Crop::setType(const std::string &newType)
{
    this->type = newType;
};
void Crop::setSupplier(const std::string &newSupplier)
{
    this->supplier = newSupplier;
};
void Crop::setNutritionalInformation(const std::string &newNutritionalInformation)
{
    this->nutritionalInformation = newNutritionalInformation;
};
void Crop::setInventory(int newInventory)
{
    this->inventory = newInventory;
};
void Crop::setCostPerUnit(double newCostPerUnit)
{
    this->costPerUnit = newCostPerUnit;
};
void Crop::addStage(const std::string &stageName, const std::string &description,
                    const std::string &startDate, const std::string &endDate)
{

    CropStage *newStage = new CropStage(stageName, description, startDate, endDate);

    if (stages == nullptr)
    {
        this->stages = newStage;
    }
    else
    {
        CropStage *currentStage = stages;
        while (currentStage->next != nullptr)
        {
            currentStage = currentStage->next;
        }
        currentStage->next = newStage;
        newStage->prev = currentStage;
    }
};

// Field Class

Field::Field(const std::string &fieldName, int fieldArea)
    : name(fieldName), area(fieldArea), cropIds({})
{
    this->id = UniqueIDGenerator::generateFieldID();
}

int Field::getId() const
{
    return this->id;
}
std::string Field::getName() const
{
    return this->name;
};
int Field::getArea() const
{
    return this->area;
};
const std::vector<int> Field::getCropIds() const
{
    return cropIds;
};

void Field::setName(const std::string &newName)
{
    this->name = newName;
};
void Field::setArea(int newArea)
{
    this->area = newArea;
};
void Field::addCropId(int cropId)
{
    bool cropIdFound = false;

    for (int cropIdInField : cropIds)
    {
        if (cropIdInField == cropId)
        {
            cropIdFound = true;
            break;
        }
    }

    if (!cropIdFound)
    {
        cropIds.push_back(cropId);
    }
    else
    {
        std::cout << "Crop ID " << cropId << " is already in the field." << std::endl;
    }
};
void Field::removeCropId(int cropId)
{
    auto it = cropIds.begin();
    bool cropIdFound = false;

    for (; it != cropIds.end(); ++it)
    {
        if (*it == cropId)
        {
            cropIdFound = true;
            break;
        }
    }
    if (cropIdFound)
    {
        cropIds.erase(it);
    }
    else
    {
        std::cout << "Crop ID " << cropId << " not found in the field.\n";
    }
}

// Menu Class

char Menu::getUserChoice()
{
    char choice;
    std::cout << "Enter your choice: ";
    std::cin >> choice;
    system("cls");

    return choice;
}

char Menu::mainMenu()
{
    std::cout << "Main Menu" << std::endl
              << "1. Fields" << std::endl
              << "2. Crops" << std::endl
              << "3. Generate Reports" << std::endl
              << "4. Exit" << std::endl;
    return getUserChoice();
}

char Menu::fieldsMenu()
{
    std::cout << "Fields Menu" << std::endl
              << "1. Search Field" << std::endl
              << "2. Add Field" << std::endl
              << "3. Remove Field" << std::endl
              << "4. View Fields" << std::endl
              << "5. Back to Main Menu" << std::endl;
    return getUserChoice();
}

char Menu::fieldOptionsMenu()
{
    std::cout << "Field Options Menu" << std::endl
              << "1. Change Information" << std::endl
              << "2. Add Crop" << std::endl
              << "3. Remove Crop" << std::endl
              << "4. View Crops" << std::endl
              << "5. Back to Field Menu" << std::endl;
    return getUserChoice();
}

char Menu::changeFieldInformationMenu()
{
    std::cout << "Change Field Information Menu" << std::endl
              << "1. Change Name" << std::endl
              << "2. Change Area" << std::endl
              << "3. Back to Field Options Menu" << std::endl;
    return getUserChoice();
}

char Menu::cropsMenu()
{
    std::cout << "Crops Menu" << std::endl
              << "1. Search Crop" << std::endl
              << "2. Add Crop" << std::endl
              << "3. Remove Crop" << std::endl
              << "4. View All Crops" << std::endl
              << "5. Back to Main Menu" << std::endl;
    return getUserChoice();
}

char Menu::cropOptionsMenu()
{
    std::cout << "Crop Options Menu" << std::endl
              << "1. Change Information" << std::endl
              << "2. Add Stage" << std::endl
              << "3. Back to Crops Menu" << std::endl;
    return getUserChoice();
}

char Menu::changeCropInformationMenu()
{
    std::cout << "Change Crop Information Menu" << std::endl
              << "1. Change Crop Name" << std::endl
              << "2. Change Crop Type" << std::endl
              << "3. Change Supplier" << std::endl
              << "4. Change Nutritional Information" << std::endl
              << "5. Change Inventory" << std::endl
              << "6. Change Cost Per Unit" << std::endl
              << "7. Back to Crop Options Menu" << std::endl;
    return getUserChoice();
}

// Farm Manager Class

void FarmManager::changeFieldName(Field *field)
{
    std::string newFieldName;
    std::cout << "Enter the new field name: ";
    std::cin.ignore();
    std::getline(std::cin, newFieldName);

    field->setName(newFieldName);
    std::cout << "Field name changed successfully." << std::endl;
}

void FarmManager::changeFieldArea(Field *field)
{
    int newFieldArea;
    std::cout << "Enter the new field area: ";
    std::cin >> newFieldArea;

    field->setArea(newFieldArea);
    std::cout << "Field area changed successfully." << std::endl;
}

void FarmManager::addCropInField(Field *field)
{
    std::cout << "Available Crops:" << std::endl;

    viewAllCrops();
    int cropId;
    std::cout << "Enter crop ID to add: ";
    std::cin >> cropId;

    bool validCropId = false;

    for (const auto &crop : crops)
    {
        if (crop.getId() == cropId)
        {
            validCropId = true;
            break;
        }
    }

    if (validCropId)
    {
        const auto &cropIds = field->getCropIds();
        bool cropAlreadyFound = false;

        for (int cropIdInField : cropIds)
        {
            if (cropId == cropIdInField)
            {
                cropAlreadyFound = true;
                break;
            }
        }

        if (!cropAlreadyFound)
        {
            for (auto &crop : crops)
            {
                if (crop.getId() == cropId)
                {
                    crop.setFieldId(field->getId());
                    break;
                }
            }

            field->addCropId(cropId);
            std::cout << "Crop added to the field successfully." << std::endl;
            return;
        }
        else
        {
            std::cout << "Crop is already present in the field." << std::endl;
        }
    }
    else
    {
        std::cout << "Invalid crop ID. Please enter a valid ID." << std::endl;
    }

    std::cout << "Crop not added to the field." << std::endl;
}

void FarmManager::removeCropFromField(Field *field)
{
    viewCropsInField(field);

    int cropId;
    std::cout << "Enter crop ID to remove: ";
    std::cin >> cropId;

    const auto &cropIds = field->getCropIds();
    if (cropId >= 0 && cropId < crops.size())
    {
        bool cropFound = false;

        for (int i = 0; i < cropIds.size(); ++i)
        {
            if (cropId == cropIds[i])
            {
                crops[cropId].setFieldId(-1);
                field->removeCropId(cropId);
                cropFound = true;
                std::cout << "Crop removed from the field successfully." << std::endl;
                break;
            }
        }

        if (!cropFound)
        {
            std::cout << "Crop ID " << cropId << " not found in the field." << std::endl;
        }
    }
    else
    {
        std::cout << "Invalid crop ID. Please enter a valid ID." << std::endl;
    }
}

void FarmManager::viewCropsInField(Field *field)
{
    const auto &cropIds = field->getCropIds();

    if (cropIds.empty())
    {
        std::cout << "No crops in the field." << std::endl;
        return;
    }

    std::cout << "Crops in the field" << std::endl;

    std::cout << std::setw(24) << std::right << "List of Crops" << std::endl
              << std::setw(5) << std::left << "ID"
              << std::setw(20) << std::left << "Name"
              << std::setw(5) << std::left << "Inventory" << std::endl
              << std::endl;
    for (const auto cropId : field->getCropIds())
    {
        int cropIndex = binarySearchCrop(crops, cropId);
        if (cropIndex != -1)
        {
            std::cout << std::setw(5) << std::left << crops[cropIndex].getId()
                      << std::setw(20) << std::left << crops[cropIndex].getName()
                      << std::setw(5) << std::left << crops[cropIndex].getInventory() << std::endl;
        }
    }
    std::cout << std::endl;
}

void FarmManager::searchField()
{

    viewAllFields();

    std::string fieldName;
    std::cout << "Enter the field name to search: ";
    std::cin.ignore();
    std::getline(std::cin, fieldName);

    bool found = false;

    for (auto &field : fields)
    {
        if (field.getName() == fieldName)
        {
            system("cls");
            std::cout << "------------ Farm Management and Crop Life Cycle Tracker ------------" << std::endl
                      << std::endl;

            found = true;

            char fieldOptionChoice;

            do
            {
                std::cout << std::setw(10) << std::left << "ID: " << field.getId() << std::endl
                          << std::setw(10) << std::left << "Name: " << field.getName() << std::endl
                          << std::setw(10) << std::left << "Area: " << field.getArea() << std::endl
                          << std::endl;
                fieldOptionChoice = Menu::fieldOptionsMenu();

                switch (fieldOptionChoice)
                {
                case '1':
                {
                    char changeFieldInformationChoice;
                    do
                    {
                        changeFieldInformationChoice = Menu::changeFieldInformationMenu();

                        switch (changeFieldInformationChoice)
                        {
                        case '1':
                            changeFieldName(&field);
                            pressAnyKeyToContinue();
                            break;
                        case '2':
                            changeFieldArea(&field);
                            pressAnyKeyToContinue();
                            break;
                        case '3':
                            break;

                        default:
                            std::cout << "Invalid choice. Please try again." << std::endl;
                            pressAnyKeyToContinue();
                            break;
                        }

                    } while (changeFieldInformationChoice != '3');

                    break;
                }
                case '2':
                    addCropInField(&field);
                    pressAnyKeyToContinue();
                    break;
                case '3':
                    removeCropFromField(&field);
                    pressAnyKeyToContinue();
                    break;
                case '4':
                    viewCropsInField(&field);
                    break;

                case '5':
                    break;

                default:
                    std::cout << "Invalid choice. Please try again." << std::endl;
                    pressAnyKeyToContinue();
                    break;
                };
            } while (fieldOptionChoice != '5');

            break;
        }
    }

    if (!found)
    {
        std::cout << "Field not found." << std::endl;
        pressAnyKeyToContinue();
    }
}

void FarmManager::addField()
{
    std::string fieldName;
    int fieldArea;

    std::cout << "Enter field name: ";
    std::cin.ignore();
    std::getline(std::cin, fieldName);

    std::cout << "Enter field area: ";
    std::cin >> fieldArea;

    fields.emplace_back(fieldName, fieldArea);
    std::cout << "Field added successfully." << std::endl;
}

void FarmManager::deleteField()
{
    std::cout << "List of Fields:" << std::endl;
    viewAllFields();

    int fieldId;
    std::cout << "Enter the ID of the field to delete: ";
    std::cin.ignore();
    std::cin >> fieldId;

    bool found = false;

    for (auto it = fields.begin(); it != fields.end(); ++it)
    {
        if (it->getId() == fieldId)
        {
            found = true;
            fields.erase(it);
            std::cout << "Field deleted successfully." << std::endl;
            break;
        }
    }

    if (!found)
    {
        std::cout << "Field not found." << std::endl;
    }
}

int FarmManager::binarySearchCrop(const std::vector<Crop> &crops, int targetId)
{
    int low = 0;
    int high = crops.size() - 1;

    while (low <= high)
    {
        int mid = low + (high - low) / 2;
        int midId = crops[mid].getId();

        if (midId == targetId)
        {
            return mid;
        }
        else if (midId < targetId)
        {
            low = mid + 1;
        }
        else
        {
            high = mid - 1;
        }
    }

    return -1;
}

void FarmManager::viewAllFields()
{
    std::cout << std::setw(24) << std::right << "List of Fields" << std::endl
              << std::setw(5) << std::left << "ID"
              << std::setw(20) << std::left << "Name"
              << std::setw(10) << std::left << "Area"
              << std::setw(50) << std::left << "Crops" << std::endl
              << std::endl;
    for (const auto &field : fields)
    {
        std::cout << std::setw(5) << std::left << field.getId()
                  << std::setw(20) << std::left << field.getName()
                  << std::setw(10) << std::left << field.getArea();

        for (const auto cropId : field.getCropIds())
        {
            int cropIndex = binarySearchCrop(crops, cropId);
            if (cropIndex != -1)
            {
                std::cout << crops[cropIndex].getName() << ", ";
            }
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

void FarmManager::changeCropName(Crop *crop)
{
    std::string newCropName;
    std::cout << "Enter the new crop name: ";
    std::cin.ignore();
    std::getline(std::cin, newCropName);

    crop->setName(newCropName);
    std::cout << "\nCrop name changed successfully." << std::endl;
}

void FarmManager::changeCropType(Crop *crop)
{
    std::string newCropType;
    std::cout << "Enter the new crop type: ";
    std::cin.ignore();
    std::getline(std::cin, newCropType);

    crop->setType(newCropType);
    std::cout << "\nCrop type changed successfully." << std::endl;
}

void FarmManager::changeCropSupplier(Crop *crop)
{
    std::string newCropSupplier;
    std::cout << "Enter the new crop supplier: ";
    std::cin.ignore();
    std::getline(std::cin, newCropSupplier);

    crop->setSupplier(newCropSupplier);
    std::cout << "\nCrop supplier changed successfully." << std::endl;
}

void FarmManager::changeCropNutritionalInformation(Crop *crop)
{
    std::string newCropNutritionalInformation;
    std::cout << "Enter the new crop nutritional information: ";
    std::cin.ignore();
    std::getline(std::cin, newCropNutritionalInformation);

    crop->setNutritionalInformation(newCropNutritionalInformation);
    std::cout << "\nCrop nutritional information changed successfully." << std::endl;
}

void FarmManager::changeCropInventory(Crop *crop)
{
    int newCropInventory;
    std::cout << "Enter the new crop inventory: ";
    std::cin >> newCropInventory;

    crop->setInventory(newCropInventory);
    std::cout << "\nCrop inventory changed successfully." << std::endl;
}

void FarmManager::changeCropCostPerUnit(Crop *crop)
{
    int newCropCostPerUnit;
    std::cout << "Enter the new crop cost per unit: ";
    std::cin >> newCropCostPerUnit;

    crop->setCostPerUnit(newCropCostPerUnit);
    std::cout << "\nCrop cost per unit changed successfully." << std::endl;
}

void FarmManager::addCropStage(Crop *crop)
{
    std::cout << "ID: " << std::setw(20) << std::left << crop->getId() << std::endl
              << "Name: " << std::setw(20) << std::left << crop->getName() << std::endl
              << std::endl;

    const CropStage *currentStage = crop->getStages();
    std::cout << "Current Stages:\n";
    if (currentStage == nullptr)
    {
        std::cout << "No stages found." << std::endl;
    }
    else
    {
        std::cout << std::setw(5) << std::left << "No."
                  << std::setw(20) << std::left << "Stage Name"
                  << std::setw(30) << std::left << "Description"
                  << std::setw(15) << std::left << "Start Date"
                  << std::setw(15) << std::left << "End Date" << std::endl
                  << std::endl;
    }
    int i = 0;
    while (currentStage != nullptr)
    {
        std::cout << std::setw(5) << std::left << i + 1
                  << std::setw(20) << std::left << currentStage->getName()
                  << std::setw(30) << std::left << currentStage->getDescription()
                  << std::setw(15) << std::left << currentStage->getStartDate()
                  << std::setw(15) << std::left << currentStage->getEndDate() << std::endl;

        currentStage = currentStage->getNext();
        i++;
    }
    std::cout << std::endl;

    std::string stageName, description, startDate, endDate;

    std::cout << "\nEnter new stage name: ";
    std::cin.ignore();
    std::getline(std::cin, stageName);

    std::cout << "Enter new stage description: ";
    std::getline(std::cin, description);

    std::cout << "Enter new start date: ";
    std::getline(std::cin, startDate);

    std::cout << "Enter new end date: ";
    std::getline(std::cin, endDate);

    crop->addStage(stageName, description, startDate, endDate);
    std::cout << "\nStage added successfully" << std::endl;
}

void FarmManager::searchCrop()
{
    viewAllCrops();

    std::string cropName;
    std::cout << "Enter the crop name to search: ";
    std::cin.ignore();
    std::getline(std::cin, cropName);

    bool found = false;

    for (auto &crop : crops)
    {
        if (crop.getName() == cropName)
        {
            std::cout << "------------ Farm Management and Crop Life Cycle Tracker ------------" << std::endl
                      << std::endl;
            system("cls");

            found = true;

            char cropOptionChoice;

            do
            {
                std::cout << std::setw(20) << std::left << "ID: " << crop.getId() << std::endl
                          << std::setw(20) << std::left << "Name: " << crop.getName() << std::endl
                          << std::setw(20) << std::left << "Supplier: " << crop.getSupplier() << std::endl
                          << std::setw(20) << std::left << "Nutritional Info.: " << crop.getNutritionalInformation() << std::endl
                          << std::setw(20) << std::left << "Inventory: " << crop.getInventory() << std::endl
                          << std::setw(20) << std::left << "Cost Per Unit: " << crop.getCostPerUnit() << std::endl

                          << std::endl;

                const CropStage *currentStage = crop.getStages();
                std::cout << "Current Stages:\n";
                if (currentStage == nullptr)
                {
                    std::cout << "No stages found." << std::endl
                              << std::endl;
                }
                else
                {
                    std::cout << std::setw(5) << std::left << "No."
                              << std::setw(20) << std::left << "Stage Name"
                              << std::setw(30) << std::left << "Description"
                              << std::setw(15) << std::left << "Start Date"
                              << std::setw(15) << std::left << "End Date" << std::endl
                              << std::endl;
                }
                int i = 0;
                while (currentStage != nullptr)
                {
                    std::cout << std::setw(5) << std::left << i + 1
                              << std::setw(20) << std::left << currentStage->getName()
                              << std::setw(30) << std::left << currentStage->getDescription()
                              << std::setw(15) << std::left << currentStage->getStartDate()
                              << std::setw(15) << std::left << currentStage->getEndDate() << std::endl;

                    currentStage = currentStage->getNext();
                    i++;
                }
                std::cout << std::endl;

                cropOptionChoice = Menu::cropOptionsMenu();

                switch (cropOptionChoice)
                {
                case '1':

                    char changeCropInformationChoice;

                    do
                    {
                        changeCropInformationChoice = Menu::changeCropInformationMenu();

                        switch (changeCropInformationChoice)
                        {
                        case '1':
                            changeCropName(&crop);
                            pressAnyKeyToContinue();
                            break;
                        case '2':
                            changeCropType(&crop);
                            pressAnyKeyToContinue();
                            break;
                        case '3':
                            changeCropSupplier(&crop);
                            pressAnyKeyToContinue();
                            break;
                        case '4':
                            changeCropNutritionalInformation(&crop);
                            pressAnyKeyToContinue();
                            break;
                        case '5':
                            changeCropInventory(&crop);
                            pressAnyKeyToContinue();
                            break;
                        case '6':
                            changeCropCostPerUnit(&crop);
                            pressAnyKeyToContinue();
                            break;
                        case '7':
                            break;

                        default:
                            std::cout << "Invalid choice. Please try again." << std::endl;
                            pressAnyKeyToContinue();
                            break;
                        }

                    } while (changeCropInformationChoice != '7');

                    break;

                case '2':
                    addCropStage(&crop);
                    pressAnyKeyToContinue();
                    break;

                case '3':
                    break;

                default:
                    std::cout << "Invalid choice. Please try again." << std::endl;
                    pressAnyKeyToContinue();
                    break;
                }

            } while (cropOptionChoice != '3');

            break;
        }
    }

    if (!found)
    {
        std::cout << "Crop not found." << std::endl;
        pressAnyKeyToContinue();
    }
}

void FarmManager::addCrop()
{
    std::string cropName, cropType, supplier, nutritionalInfo;
    int inventory;
    double costPerUnit;

    std::cout << "Enter crop name: ";
    std::cin.ignore();
    std::getline(std::cin, cropName);

    std::cout << "Enter crop type: ";
    std::getline(std::cin, cropType);

    std::cout << "Enter supplier: ";
    std::getline(std::cin, supplier);

    std::cout << "Enter nutritional information: ";
    std::getline(std::cin, nutritionalInfo);

    std::cout << "Enter inventory: ";
    std::cin >> inventory;

    std::cout << "Enter cost per unit: ";
    std::cin >> costPerUnit;

    crops.emplace_back(cropName, cropType, supplier, nutritionalInfo, inventory, costPerUnit);
    std::cout << "Crop added successfully." << std::endl;
}

void FarmManager::deleteCrop()
{
    viewAllCrops();

    int cropId;
    std::cout << "Enter the ID of the crop to delete: ";
    std::cin >> cropId;

    bool found = false;

    for (auto it = crops.begin(); it != crops.end(); ++it)
    {
        if (it->getId() == cropId)
        {
            found = true;
            crops.erase(it);
            std::cout << "Crop deleted successfully." << std::endl;
            break;
        }
    }

    if (!found)
    {
        std::cout << "Crop not found." << std::endl;
    }
}

void FarmManager::viewAllCrops()
{
    std::cout << std::setw(24) << std::right << "List of Crops" << std::endl
              << std::setw(5) << std::left << "ID"
              << std::setw(20) << std::left << "Name"
              << std::setw(5) << std::left << "Inventory" << std::endl
              << std::endl;
    for (const auto &crop : crops)
    {
        std::cout << std::setw(5) << std::left << crop.getId()
                  << std::setw(20) << std::left << crop.getName()
                  << std::setw(5) << std::left << crop.getInventory() << std::endl;
    }
    std::cout << std::endl;
}

int FarmManager::partitionCrops(std::vector<Crop> &quickCrops, int low, int high)
{
    int pivotIndex = low;
    Crop pivot = quickCrops[pivotIndex];
    int left = low + 1;
    int right = high;

    while (left <= right)
    {
        while (left <= right && quickCrops[left].getInventory() >= pivot.getInventory())
        {
            left++;
        }
        while (left <= right && quickCrops[right].getInventory() <= pivot.getInventory())
        {
            right--;
        }
        if (left < right)
        {
            std::swap(quickCrops[left], quickCrops[right]);
            left++;
            right--;
        }
    }
    if (pivotIndex != right)
    {
        std::swap(quickCrops[pivotIndex], quickCrops[right]);
    }
    return right;
}

void FarmManager::quickSortCrops(std::vector<Crop> &quickCrops, int low, int high)
{
    if (low < high)
    {
        int p = partitionCrops(quickCrops, low, high);
        quickSortCrops(quickCrops, low, p - 1);
        quickSortCrops(quickCrops, p + 1, high);
    }
}

int FarmManager::partitionFields(std::vector<Field> &quickFields, int low, int high)
{
    int pivotIndex = low;
    Field pivot = quickFields[pivotIndex];
    int left = low + 1;
    int right = high;

    while (left <= right)
    {
        while (left <= right && quickFields[left].getArea() >= pivot.getArea())
        {
            left++;
        }
        while (left <= right && quickFields[right].getArea() <= pivot.getArea())
        {
            right--;
        }
        if (left < right)
        {
            std::swap(quickFields[left], quickFields[right]);
            left++;
            right--;
        }
    }
    if (pivotIndex != right)
    {
        std::swap(quickFields[pivotIndex], quickFields[right]);
    }
    return right;
}

void FarmManager::quickSortFields(std::vector<Field> &quickFields, int low, int high)
{
    if (low < high)
    {
        int p = partitionFields(quickFields, low, high);
        quickSortFields(quickFields, low, p - 1);
        quickSortFields(quickFields, p + 1, high);
    }
}

void FarmManager::generateReport()
{
    std::vector<Crop> tempCrops = crops;
    quickSortCrops(tempCrops, 0, tempCrops.size() - 1);
    std::cout << "----------------------- Inventory Wise Crops Report -----------------------" << std::endl
              << std::endl;
    std::cout << std::setw(5) << std::left << "ID"
              << std::setw(20) << std::left << "Name"
              << std::setw(12) << std::left << "Inventory"
              << std::setw(30) << std::left << "Stages" << std::endl
              << std::endl;
    for (const auto &crop : tempCrops)
    {
        std::cout << std::setw(5) << std::left << crop.getId()
                  << std::setw(20) << std::left << crop.getName()
                  << std::setw(12) << std::left << crop.getInventory();

        const CropStage *currentStage = crop.getStages();
        while (currentStage != nullptr)
        {
            std::cout << currentStage->getName() << ", ";
            currentStage = currentStage->getNext();
        }
        std::cout << std::endl;
    }
    std::cout << std::endl
              << std::endl
              << std::endl;

    std::vector<Field> tempFields = fields;
    quickSortFields(tempFields, 0, tempFields.size() - 1);
    std::cout << "----------------------- Area Wise Fields Report -----------------------" << std::endl
              << std::endl;
    std::cout << std::setw(5) << std::left << "ID"
              << std::setw(20) << std::left << "Name"
              << std::setw(10) << std::left << "Area"
              << std::setw(50) << std::left << "Crops" << std::endl
              << std::endl;
    for (const auto &field : tempFields)
    {
        std::cout << std::setw(5) << std::left << field.getId()
                  << std::setw(20) << std::left << field.getName()
                  << std::setw(10) << std::left << field.getArea();

        for (const auto cropId : field.getCropIds())
        {
            int cropIndex = binarySearchCrop(crops, cropId);
            if (cropIndex != -1)
            {
                std::cout << crops[cropIndex].getName() << ", ";
            }
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

FarmManager::FarmManager()
{

    Crop crop1("Tomato", "Vegetable", "Farm Fresh Foods", "Calories: 18 Carbs: 4g Fiber: 1g", 150, 2);
    crop1.addStage("Seedling", "Young tomato plants", "10Jan23", "28Feb23");
    crop1.addStage("Transplanting", "Moving tomato plants to a larger space", "01Mar23", "15Mar23");
    crop1.addStage("Flowering", "Tomato plants blossoming", "20Mar23", "05Apr23");
    crops.push_back(crop1);

    Crop crop2("Lettuce", "Leafy Green", "Green Fields Farm", "Calories: 5 Carbs: 1g Fiber: 0.5g", 200, 1);
    crop2.addStage("Germination", "Lettuce seeds sprouting", "15Feb23", "05Mar23");
    crop2.addStage("Transplanting", "Moving lettuce seedlings to the field", "10Mar23", "25Mar23");
    crop2.addStage("Growth", "Developing lettuce leaves", "01Apr23", "15Apr23");
    crops.push_back(crop2);

    Crop crop3("Apple", "Fruit", "Orchard Delights", "Calories: 95 Carbs: 25g Fiber: 4g", 100, 3);
    crop3.addStage("Flowering", "Apple tree blossoms", "01Apr23", "15Apr23");
    crop3.addStage("FruitSetting", "Formation of young apples", "20Apr23", "05May23");
    crop3.addStage("Harvesting", "Collecting mature apples", "01Sep23", "15Sep23");
    crops.push_back(crop3);

    Crop crop4("Carrot", "Root Vegetable", "Harvest Haven", "Calories: 41 Carbs: 10g Fiber: 2g", 120, 1.5);
    crop4.addStage("Growth", "Carrot roots developing", "20Mar23", "10Apr23");
    crop4.addStage("Harvesting", "Collecting mature carrots", "01May23", "15May23");
    crops.push_back(crop4);

    Crop crop5("Broccoli", "Brassica", "Fresh Farms", "Calories: 55 Carbs: 11g Fiber: 5g", 80, 2.5);
    crop5.addStage("Germination", "Broccoli seeds sprouting", "01Jun23", "15Jun23");
    crop5.addStage("Fruiting", "Formation of broccoli heads", "20Jun23", "05Jul23");
    crop5.addStage("Harvesting", "Collecting mature broccoli", "10Jul23", "25Jul23");
    crops.push_back(crop5);

    Crop crop6("Strawberry", "Berry", "Sweet Berries Co.", "Calories: 4 Carbs: 1g Fiber: 0.5g", 180, 4);
    crop6.addStage("Flowering", "Strawberry plants blossoming", "01Aug23", "15Aug23");
    crop6.addStage("Fruiting", "Formation of strawberries", "20Aug23", "05Sep23");
    crop6.addStage("Harvesting", "Collecting ripe strawberries", "10Sep23", "25Sep23");
    crops.push_back(crop6);

    Crop crop7("Potato", "Tuber", "Golden Harvest", "Calories: 130 Carbs: 30g Fiber: 3g", 90, 1.8);
    crop7.addStage("Growth", "Potato tubers maturing", "15Apr23", "01May23");
    crop7.addStage("Harvesting", "Collecting mature potatoes", "10May23", "25May23");
    crops.push_back(crop7);

    Crop crop8("Spinach", "Leafy Green", "Nature's Greens", "Calories: 7 Carbs: 1g Fiber: 0.7g", 220, 1.2);
    crop8.addStage("Germination", "Spinach seeds sprouting", "01Jun23", "15Jun23");
    crop8.addStage("Harvesting", "Collecting mature spinach", "01Jul23", "15Jul23");
    crops.push_back(crop8);

    Crop crop9("Orange", "Citrus", "Fruit Paradise", "Calories: 62 Carbs: 15g Fiber: 3g", 150, 2.2);
    crop9.addStage("Flowering", "Orange trees blossoming", "01Aug23", "15Aug23");
    crop9.addStage("Fruiting", "Formation of oranges", "20Aug23", "05Sep23");
    crop9.addStage("Harvesting", "Collecting ripe oranges", "10Sep23", "25Sep23");
    crops.push_back(crop9);

    Crop crop10("Cucumber", "Gourd", "Fresh Picks Co.", "Calories: 16 Carbs: 4g Fiber: 1g", 120, 1.2);
    crop10.addStage("Growth", "Cucumber fruits developing", "20Jun23", "05Jul23");
    crop10.addStage("Harvesting", "Collecting mature cucumbers", "10Jul23", "25Jul23");
    crops.push_back(crop10);

    Crop crop11("Grapes", "Berry", "Harvest Vineyards", "Calories: 69 Carbs: 18g Fiber: 1g", 100, 3.5);
    crop11.addStage("Flowering", "Grapevines blossoming", "01Sep23", "15Sep23");
    crop11.addStage("Fruiting", "Formation of grape clusters", "20Sep23", "05Oct23");
    crop11.addStage("Harvesting", "Collecting ripe grapes", "10Oct23", "25Oct23");
    crops.push_back(crop11);

    Crop crop12("Cabbage", "Brassica", "Farm Fresh Foods", "Calories: 22 Carbs: 5g Fiber: 2g", 80, 1.3);
    crop12.addStage("Germination", "Cabbage seeds sprouting", "01Jun23", "15Jun23");
    crop12.addStage("Harvesting", "Collecting mature cabbages", "01Jul23", "15Jul23");
    crops.push_back(crop12);

    Crop crop13("Mango", "Fruit", "Tropical Treats", "Calories: 60 Carbs: 15g Fiber: 3g", 130, 2.8);
    crop13.addStage("Flowering", "Mango trees blossoming", "01Nov23", "15Nov23");
    crop13.addStage("Fruiting", "Formation of mango fruits", "20Nov23", "05Dec23");
    crop13.addStage("Harvesting", "Collecting ripe mangoes", "10Dec23", "25Dec23");
    crops.push_back(crop13);

    Crop crop14("Onion", "Bulb Vegetable", "Golden Harvest", "Calories: 44 Carbs: 10g Fiber: 2g", 110, 1);
    crop14.addStage("Growth", "Onion bulbs maturing", "05Aug23", "20Aug23");
    crop14.addStage("Harvesting", "Collecting mature onions", "01Sep23", "15Sep23");
    crops.push_back(crop14);

    Crop crop15("Blueberry", "Berry", "Sweet Berries Co.", "Calories: 29 Carbs: 7g Fiber: 2g", 160, 3.2);
    crop15.addStage("Flowering", "Blueberry bushes blossoming", "01Dec23", "15Dec23");
    crop15.addStage("Fruiting", "Formation of blueberries", "20Dec23", "05Jan24");
    crop15.addStage("Harvesting", "Collecting ripe blueberries", "10Jan24", "25Jan24");
    crops.push_back(crop15);

    Crop crop16("Cauliflower", "Brassica", "Fresh Farms", "Calories: 25 Carbs: 5g Fiber: 2g", 90, 2.1);
    crop16.addStage("Harvesting", "Collecting mature cauliflower", "15Jan24", "30Jan24");
    crops.push_back(crop16);

    Crop crop17("Peach", "Fruit", "Orchard Delights", "Calories: 59 Carbs: 15g Fiber: 2g", 120, 2.5);
    crop17.addStage("Flowering", "Peach trees blossoming", "01Feb24", "15Feb24");
    crop17.addStage("Fruiting", "Formation of peaches", "20Feb24", "05Mar24");
    crop17.addStage("Harvesting", "Collecting ripe peaches", "10Mar24", "25Mar24");
    crops.push_back(crop17);

    Crop crop18("Zucchini", "Gourd", "Green Fields Farm", "Calories: 17 Carbs: 3g Fiber: 1g", 110, 1.5);
    crop18.addStage("Growth", "Zucchini fruits developing", "10Mar24", "25Mar24");
    crop18.addStage("Harvesting", "Collecting mature zucchinis", "01Apr24", "15Apr24");
    crops.push_back(crop18);

    Crop crop19("Cherry", "Berry", "Harvest Vineyards", "Calories: 50 Carbs: 12g Fiber: 2g", 140, 3);
    crop19.addStage("Fruiting", "Collecting ripe cherries", "01May24", "15May24");
    crop19.addStage("Harvesting", "Collecting mature cherries", "01Jun24", "15Jun24");
    crops.push_back(crop19);

    Crop crop20("Bell Pepper", "Vegetable", "Nature's Greens", "Calories: 25 Carbs: 6g Fiber: 2g", 100, 2);
    crop20.addStage("Growth", "Bell pepper fruits developing", "20Jun24", "05Jul24");
    crops.push_back(crop20);

    Crop crop21("Watermelon", "Melon", "Fruit Paradise", "Calories: 30 Carbs: 8g Fiber: 1g", 180, 2.5);
    crops.push_back(crop21);
    Crop crop22("Cantaloupe", "Melon", "Tropical Treats", "Calories: 50 Carbs: 12g Fiber: 2g", 130, 2.8);
    crops.push_back(crop22);
    Crop crop23("Radish", "Root Vegetable", "Harvest Haven", "Calories: 19 Carbs: 4g Fiber: 2g", 150, 1.5);
    crops.push_back(crop23);
    Crop crop24("Pineapple", "Tropical", "Fruit Paradise", "Calories: 50 Carbs: 13g Fiber: 1g", 120, 3);
    crops.push_back(crop24);
    Crop crop25("Kale", "Leafy Green", "Nature's Greens", "Calories: 33 Carbs: 6g Fiber: 2g", 90, 1.7);
    crops.push_back(crop25);
    Crop crop26("Cranberry", "Berry", "Sweet Berries Co.", "Calories: 46 Carbs: 12g Fiber: 2g", 120, 3.3);
    crops.push_back(crop26);
    Crop crop27("Garlic", "Bulb Vegetable", "Golden Harvest", "Calories: 42 Carbs: 9g Fiber: 1g", 110, 1.2);
    crops.push_back(crop27);
    Crop crop28("Asparagus", "Stalk Vegetable", "Fresh Picks Co.", "Calories: 20 Carbs: 4g Fiber: 2g", 80, 2.2);
    crops.push_back(crop28);

    Field field1("Field A", 480);
    field1.addCropId(1);
    field1.addCropId(2);
    field1.addCropId(3);
    fields.push_back(field1);
    Field field2("Field B", 720);
    field2.addCropId(4);
    field2.addCropId(5);
    field2.addCropId(6);
    fields.push_back(field2);
    Field field3("Field C", 580);
    field3.addCropId(7);
    field3.addCropId(8);
    fields.push_back(field3);
    Field field4("Field D", 820);
    field4.addCropId(9);
    fields.push_back(field4);
    Field field5("Field E", 540);
    field5.addCropId(10);
    field5.addCropId(11);
    field5.addCropId(12);
    field4.addCropId(13);
    fields.push_back(field5);
    Field field6("Field F", 920);
    field6.addCropId(14);
    field6.addCropId(15);
    fields.push_back(field6);
    Field field7("Field G", 630);
    field7.addCropId(16);
    fields.push_back(field7);
    Field field8("Field H", 770);
    field8.addCropId(17);
    field8.addCropId(18);
    field8.addCropId(19);
    fields.push_back(field8);
    Field field9("Field I", 690);
    field9.addCropId(20);
    field9.addCropId(21);
    field9.addCropId(22);
    fields.push_back(field9);
    Field field10("Field J", 620);
    field10.addCropId(23);
    field10.addCropId(24);
    field10.addCropId(25);
    field10.addCropId(26);
    fields.push_back(field10);
}